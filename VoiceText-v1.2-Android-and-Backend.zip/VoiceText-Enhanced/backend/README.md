# VoiceText backend (v1.2)

This backend provides direct AI story rewriting and an optional personal voice-clone adapter.

## Safety defaults

- Voice cloning is **OFF** by default (`VOICE_CLONING_ENABLED=false`).
- Voice cloning must remain off unless a parent/guardian or adult project administrator has reviewed the current voice provider terms, age eligibility, privacy terms, and consent requirements and is legally able to operate the provider account.
- Only the speaker's own voice may be submitted. Do not upload another person's recording.
- The backend does not write uploaded audio to disk; it forwards the in-memory bytes to the provider. The provider may retain the resulting voice profile under its own account and terms.
- The provider account owner must manage the provider-side clone and deletion. VoiceText's DELETE endpoint requests provider deletion but the owner should verify completion in the provider account.
- Use HTTPS in deployment. Never put OpenAI or voice-provider keys in the Android APK or source repository.

## Configure and run

1. Copy `.env.example` to `.env`.
2. Set a long random `APP_ACCESS_TOKEN` and `OPENAI_API_KEY`.
3. Keep `VOICE_CLONING_ENABLED=false` unless the adult-admin safeguards above have been completed. If enabled, configure `ELEVENLABS_API_KEY` on the server only.
4. Run:

   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
   pip install -r requirements.txt
   uvicorn app.main:app --host 0.0.0.0 --port 8000
   ```

5. Deploy behind HTTPS. Do not expose an unprotected development server to the public internet.
6. In VoiceText, enter the HTTPS backend URL and the app access token supplied by the backend administrator.

## API

- `GET /health`
- `POST /api/story/rewrite` JSON `{ "text": "...", "style": "Cinematic narration" }`
- `POST /api/voice/clone` multipart fields `audio`, `voice_name`, `confirms_own_voice`
- `POST /api/voice/speak` JSON `{ "voice_id": "...", "text": "..." }`
- `DELETE /api/voice/{voice_id}`

All `/api/*` routes require `X-App-Token`.

## Production notes

This is a starter backend, not a production identity or account system. Before public release add per-user authentication, request quotas, abuse monitoring, secure secret management, audit logs that do not store voice samples, and a privacy/retention policy. Do not rely on a checkbox as proof of identity; provider verification and adult administration remain required.
