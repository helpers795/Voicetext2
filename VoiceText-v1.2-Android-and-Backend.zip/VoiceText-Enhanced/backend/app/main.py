import base64
import hmac
import os
from typing import Annotated

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

load_dotenv()
app = FastAPI(title="VoiceText API", version="1.2.0")

APP_TOKEN = os.getenv("APP_ACCESS_TOKEN", "")
OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
ELEVEN_KEY = os.getenv("ELEVENLABS_API_KEY", "")
VOICE_ENABLED = os.getenv("VOICE_CLONING_ENABLED", "false").lower() == "true"
MAX_AUDIO_BYTES = int(os.getenv("MAX_AUDIO_MB", "12")) * 1024 * 1024
MAX_TEXT_CHARS = int(os.getenv("MAX_TEXT_CHARS", "12000"))

STYLES = {
    "Emotional storytelling": "Warm, sincere and emotionally engaging, without melodrama.",
    "Cinematic narration": "Visual, atmospheric and paced like a documentary narration.",
    "Suspense and mystery": "Build curiosity and tension gradually, without adding frightening or graphic content.",
    "Inspirational": "Hopeful, encouraging and grounded; avoid exaggerated promises.",
    "Friendly and conversational": "Natural, clear and friendly, like explaining something to a friend.",
    "Simple and clear": "Plain language, short sentences and easy-to-follow structure.",
}


def require_token(x_app_token: str | None):
    if not APP_TOKEN:
        raise HTTPException(503, "Backend administrator has not configured APP_ACCESS_TOKEN.")
    if not x_app_token or not hmac.compare_digest(x_app_token, APP_TOKEN):
        raise HTTPException(401, "Invalid app access token.")


class RewriteRequest(BaseModel):
    text: str = Field(min_length=1)
    style: str = Field(default="Emotional storytelling")


class SpeakRequest(BaseModel):
    voice_id: str = Field(min_length=4, max_length=100)
    text: str = Field(min_length=1)


@app.get("/health")
async def health():
    # Do not expose secrets or provider account details here.
    return {"status": "ok", "voice_cloning_available": bool(VOICE_ENABLED and ELEVEN_KEY)}


@app.post("/api/story/rewrite")
async def rewrite(body: RewriteRequest, x_app_token: Annotated[str | None, Header()] = None):
    require_token(x_app_token)
    if not OPENAI_KEY:
        raise HTTPException(503, "AI story service is not configured on the backend.")
    text = body.text.strip()
    if len(text) > MAX_TEXT_CHARS:
        raise HTTPException(413, f"Text is too long. Maximum is {MAX_TEXT_CHARS} characters.")
    style = body.style if body.style in STYLES else "Simple and clear"
    system = (
        "You are a careful narration editor. Preserve the user's meaning, names, dates and facts. "
        "Do not invent events, claims, quotes or details. Improve grammar, clarity, pacing, transitions "
        "and spoken rhythm according to the selected style. Keep the result age-appropriate and non-graphic. "
        "Return only the rewritten text."
    )
    user = f"Style: {style}. Guidance: {STYLES[style]}\n\nText to improve:\n{text}"
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {OPENAI_KEY}"},
                json={"model": OPENAI_MODEL, "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user}], "temperature": 0.7},
            )
        if response.status_code >= 400:
            raise HTTPException(502, "The AI writing provider returned an error.")
        data = response.json()
        result = data["choices"][0]["message"]["content"].strip()
        if not result:
            raise HTTPException(502, "The AI provider returned an empty result.")
        return {"text": result}
    except httpx.TimeoutException:
        raise HTTPException(504, "AI request timed out. Please try again.")
    except (KeyError, IndexError, TypeError, ValueError):
        raise HTTPException(502, "Could not read the AI provider response.")


@app.post("/api/voice/clone")
async def clone_voice(
    x_app_token: Annotated[str | None, Header()] = None,
    audio: UploadFile = File(...),
    voice_name: str = Form("My Voice"),
    confirms_own_voice: bool = Form(False),
):
    require_token(x_app_token)
    # Deliberately disabled by default. Enabling must be an adult administrator's
    # decision after reviewing current provider age rules, consent and data terms.
    if not VOICE_ENABLED:
        raise HTTPException(403, "Voice cloning is disabled. A parent/guardian or adult administrator must review and enable it first.")
    if not ELEVEN_KEY:
        raise HTTPException(503, "Voice provider is not configured on the backend.")
    if not confirms_own_voice:
        raise HTTPException(400, "Confirm that this is your own voice recording.")
    if not audio.content_type or not audio.content_type.startswith("audio/"):
        raise HTTPException(415, "Please select an audio file.")
    content = await audio.read(MAX_AUDIO_BYTES + 1)
    if len(content) > MAX_AUDIO_BYTES:
        raise HTTPException(413, f"Audio file exceeds {MAX_AUDIO_BYTES // (1024 * 1024)} MB.")
    if len(content) < 1024:
        raise HTTPException(400, "Audio file is too small or empty.")
    safe_name = "".join(c for c in voice_name if c.isalnum() or c in " -_")[:40].strip() or "My Voice"
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(
                "https://api.elevenlabs.io/v1/voices/add",
                headers={"xi-api-key": ELEVEN_KEY},
                data={"name": safe_name, "description": "User-authorized personal voice clone"},
                files={"files[]": (audio.filename or "voice-sample.mp3", content, audio.content_type)},
            )
        if response.status_code >= 400:
            raise HTTPException(502, "Voice provider could not create the voice. Check provider eligibility and settings.")
        data = response.json()
        return {"voice_id": data.get("voice_id"), "requires_verification": data.get("requires_verification", False)}
    except httpx.TimeoutException:
        raise HTTPException(504, "Voice creation timed out. Please try again later.")


@app.post("/api/voice/speak")
async def speak_voice(body: SpeakRequest, x_app_token: Annotated[str | None, Header()] = None):
    require_token(x_app_token)
    if not VOICE_ENABLED or not ELEVEN_KEY:
        raise HTTPException(403, "Voice cloning and synthesis are not enabled on this backend.")
    if len(body.text) > MAX_TEXT_CHARS:
        raise HTTPException(413, f"Text is too long. Maximum is {MAX_TEXT_CHARS} characters.")
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(
                f"https://api.elevenlabs.io/v1/text-to-speech/{body.voice_id}",
                headers={"xi-api-key": ELEVEN_KEY, "Accept": "audio/mpeg", "Content-Type": "application/json"},
                json={"text": body.text, "model_id": "eleven_multilingual_v2"},
            )
        if response.status_code >= 400:
            raise HTTPException(502, "Voice provider could not generate speech.")
        return JSONResponse({"audio_base64": base64.b64encode(response.content).decode("ascii"), "mime_type": "audio/mpeg"})
    except httpx.TimeoutException:
        raise HTTPException(504, "Speech generation timed out. Please try again.")


@app.delete("/api/voice/{voice_id}")
async def delete_voice(voice_id: str, x_app_token: Annotated[str | None, Header()] = None):
    require_token(x_app_token)
    if not VOICE_ENABLED or not ELEVEN_KEY:
        raise HTTPException(403, "Voice cloning is not enabled on this backend.")
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.delete(
                f"https://api.elevenlabs.io/v1/voices/{voice_id}",
                headers={"xi-api-key": ELEVEN_KEY},
            )
        if response.status_code >= 400:
            raise HTTPException(502, "The provider could not delete this voice. Please check the provider account.")
        return {"deleted": True}
    except httpx.TimeoutException:
        raise HTTPException(504, "Deletion request timed out. Please retry and verify in the provider account.")
