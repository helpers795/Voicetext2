# VoiceText 1.2

Native Android text-to-speech app plus a separate Python backend for direct AI rewriting and optional personal voice cloning.

## Android features
- Text input and Android TextToSpeech playback
- English (India), English (US), Hindi, and additional locales reported by installed TTS engine
- Select voices exposed by the Android TTS engine
- Speaking speed and pitch controls
- Speak, pause, resume, stop
- Upload and play a local recording
- Direct in-app AI storytelling rewrite through the configured backend
- Optional personal voice profile upload, synthesis and deletion through the backend (server-side feature flag is OFF by default)

## Important safety and privacy notes
- Voice cloning is disabled by default on the backend. It must not be enabled by a minor independently. A parent/guardian or adult project administrator must review current provider age eligibility, terms, privacy, billing and consent requirements and operate the provider account where permitted.
- Only the speaker's own voice may be uploaded. Never upload another person's recording.
- Voice recordings are sent from the app to the configured backend and then to the configured provider if voice cloning is enabled. The starter backend does not save the uploaded audio to disk, but the voice provider may retain the resulting voice profile under its account terms.
- The app access token is not a provider API key. Never enter OpenAI or voice-provider API keys in the Android app. Those keys belong only in the backend's environment.
- Use HTTPS. The included backend is a starter project, not a production identity/account system. Do not expose it publicly without adult administration, authentication hardening, quotas, abuse monitoring and a privacy policy.
- Android's local voice list is still available without the backend. The gender/voice labels vary by device engine.

## Project layout
- `app/`: Android Kotlin + Jetpack Compose app
- `backend/`: FastAPI service for story rewriting and optional voice provider integration
- `.github/workflows/build-apk.yml`: cloud APK build workflow

## Backend setup (adult/guardian-managed)
See `backend/README.md`. Voice cloning remains disabled unless the backend administrator deliberately changes `VOICE_CLONING_ENABLED` after reviewing the provider's current rules. Keep all provider keys on the server.

## Build Android APK
Requires JDK 17, Android SDK 35, Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

If building from an Android tablet, upload the whole repository to GitHub, including `.github/workflows/build-apk.yml`, then run the **Build VoiceText APK** workflow from the Actions tab and download the generated artifact.

## Status
This source package has not been compiled or device-tested in this environment. Treat the first build as a test build. If GitHub Actions reports an error, share the complete error log so the source can be corrected.
