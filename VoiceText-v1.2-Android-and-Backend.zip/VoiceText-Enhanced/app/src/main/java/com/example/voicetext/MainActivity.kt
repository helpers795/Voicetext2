package com.example.voicetext

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private data class SpeechLanguage(val label: String, val locale: Locale)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VoiceTextScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoiceTextScreen() {
    val context = LocalContext.current
    var engine by remember { mutableStateOf<TextToSpeech?>(null) }
    var ready by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Preparing speech engine…") }
    var languageMenu by remember { mutableStateOf(false) }
    var voiceMenu by remember { mutableStateOf(false) }
    var styleMenu by remember { mutableStateOf(false) }
    var selectedLanguage by remember { mutableStateOf(SpeechLanguage("English (India)", Locale("en", "IN"))) }
    var selectedVoiceName by remember { mutableStateOf("System default") }
    var selectedVoice by remember { mutableStateOf<Voice?>(null) }
    var speed by remember { mutableFloatStateOf(1f) }
    var pitch by remember { mutableFloatStateOf(1f) }
    var paused by remember { mutableStateOf(false) }
    var speaking by remember { mutableStateOf(false) }
    var lastPosition by remember { mutableIntStateOf(0) }
    var availableLanguages by remember { mutableStateOf(listOf<SpeechLanguage>()) }
    var availableVoices by remember { mutableStateOf(listOf<Voice>()) }
    var selectedStyle by remember { mutableStateOf("Emotional storytelling") }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var audioName by remember { mutableStateOf("No recording selected") }
    var audioPlaying by remember { mutableStateOf(false) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var backendUrl by remember { mutableStateOf("") }
    var backendToken by remember { mutableStateOf("") }
    var clonedVoiceId by remember { mutableStateOf("") }
    var voiceConsent by remember { mutableStateOf(false) }
    var useClonedVoice by remember { mutableStateOf(false) }
    var backendBusy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val presetLanguages = remember {
        listOf(
            SpeechLanguage("English (India)", Locale("en", "IN")),
            SpeechLanguage("English (US)", Locale.US),
            SpeechLanguage("Hindi", Locale("hi", "IN"))
        )
    }
    val styles = listOf("Emotional storytelling", "Cinematic narration", "Suspense and mystery",
        "Inspirational", "Friendly and conversational", "Simple and clear")

    fun refreshVoices(tts: TextToSpeech, locale: Locale) {
        availableVoices = tts.voices.orEmpty()
            .filter { it.locale.language == locale.language }
            .sortedBy { it.name }
        if (availableVoices.isNotEmpty()) {
            val exact = availableVoices.filter { it.locale.country == locale.country }
            if (exact.isNotEmpty()) availableVoices = exact
        }
        if (selectedVoice != null && availableVoices.none { it.name == selectedVoice?.name }) {
            selectedVoice = null
            selectedVoiceName = "System default"
        }
    }

    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            audioUri = uri
            audioName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected audio recording"
            status = "Recording selected. Use the recording player below to listen."
            mediaPlayer?.release()
            mediaPlayer = null
            audioPlaying = false
        }
    }

    DisposableEffect(Unit) {
        val tts = TextToSpeech(context) { result ->
            if (result == TextToSpeech.SUCCESS) {
                ready = true
                status = "Ready. Type text and tap Speak."
            } else {
                status = "Speech engine could not start. Check Android Text-to-Speech settings."
            }
        }
        engine = tts
        onDispose {
            tts.stop()
            tts.shutdown()
            mediaPlayer?.release()
            mediaPlayer = null
            engine = null
        }
    }

    LaunchedEffect(ready, engine) {
        val tts = engine
        if (ready && tts != null) {
            val extras = tts.availableLanguages.orEmpty().map {
                SpeechLanguage(it.getDisplayName(Locale.getDefault()).replaceFirstChar { c -> c.uppercase() }, it)
            }
            availableLanguages = (presetLanguages + extras)
                .distinctBy { "${it.locale.language}_${it.locale.country}" }
                .sortedBy { it.label }
            val result = tts.setLanguage(selectedLanguage.locale)
            refreshVoices(tts, selectedLanguage.locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                status = "${selectedLanguage.label} is unavailable. Install its voice data or choose another language."
            }
        }
    }

    DisposableEffect(engine) {
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { speaking = true; paused = false }
            override fun onDone(utteranceId: String?) {
                speaking = false
                paused = false
                lastPosition = 0
                status = "Finished speaking."
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                speaking = false; paused = false
                status = "Speech playback failed. Try another voice or language."
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                speaking = false; paused = false
                status = "Speech playback error ($errorCode)."
            }
            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                lastPosition = start
            }
        })
        onDispose { }
    }

    fun startSpeaking(from: Int = 0) {
        val full = text.trim()
        if (useClonedVoice && clonedVoiceId.isNotBlank()) {
            if (backendUrl.isBlank() || backendToken.isBlank()) { status = "Enter your backend URL and access token first."; return }
            if (full.isEmpty()) { status = "Please type or paste text first."; return }
            backendBusy = true
            status = "Generating speech with your approved voice…"
            scope.launch {
                try {
                    val file = withContext(Dispatchers.IO) {
                        BackendClient.synthesize(backendUrl, backendToken, clonedVoiceId, full.substring(from.coerceIn(0, full.length)), context)
                    }
                    mediaPlayer?.release()
                    mediaPlayer = MediaPlayer().apply {
                        setDataSource(file.absolutePath)
                        setOnCompletionListener { audioPlaying = false; speaking = false; status = "Finished speaking." }
                        prepare()
                        start()
                    }
                    speaking = true
                    audioPlaying = true
                    paused = false
                    status = "Speaking with your selected voice."
                } catch (e: Exception) {
                    status = e.message ?: "Could not generate cloned-voice speech."
                } finally { backendBusy = false }
            }
            return
        }
        val tts = engine ?: return
        if (!ready) { status = "Speech engine is still loading."; return }
        if (full.isEmpty()) { status = "Please type or paste text first."; return }
        val start = from.coerceIn(0, full.length)
        val remaining = full.substring(start)
        if (remaining.isBlank()) { status = "There is no more text to speak."; return }
        tts.setSpeechRate(speed)
        tts.setPitch(pitch)
        val result = tts.setLanguage(selectedLanguage.locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            status = "${selectedLanguage.label} is not supported by the installed speech engine."
            return
        }
        val voiceResult = selectedVoice?.let { tts.setVoice(it) } ?: TextToSpeech.SUCCESS
        if (voiceResult == TextToSpeech.ERROR) {
            status = "Selected voice could not be used. Try System default."
            return
        }
        val speakResult = tts.speak(remaining, TextToSpeech.QUEUE_FLUSH, Bundle(),
            "voicetext-${System.currentTimeMillis()}")
        if (speakResult == TextToSpeech.ERROR) status = "Could not start speech. Check TTS settings."
        else {
            speaking = true
            paused = false
            status = if (start > 0) "Resuming speech…" else "Speaking…"
        }
    }

    fun improveStoryDirect() {
        if (text.isBlank()) { status = "Enter or paste text before improving it."; return }
        if (backendUrl.isBlank() || backendToken.isBlank()) {
            status = "Add your backend URL and access token in Backend settings first."
            return
        }
        backendBusy = true
        status = "Improving your text with AI…"
        scope.launch {
            try {
                val improved = withContext(Dispatchers.IO) {
                    BackendClient.rewrite(backendUrl, backendToken, text, selectedStyle)
                }
                text = improved
                lastPosition = 0
                status = "Text improved. Review it, then tap Speak."
            } catch (e: Exception) {
                status = e.message ?: "AI rewriting failed. Check backend settings."
            } finally { backendBusy = false }
        }
    }


    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF9C8CFF),
            secondary = androidx.compose.ui.graphics.Color(0xFF70D6C5),
            background = androidx.compose.ui.graphics.Color(0xFF10111A),
            surface = androidx.compose.ui.graphics.Color(0xFF1B1D2A)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("VoiceText", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("Turn your words into expressive speech.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; lastPosition = 0 },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp),
                    label = { Text("Your text") },
                    placeholder = { Text("Type or paste something you want to hear…") },
                    supportingText = { Text("${text.length} characters") },
                    minLines = 5
                )

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("AI STORY IMPROVER", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                        Text("Turn plain text into a smoother story with emotion, pacing and a chosen narration style.",
                            style = MaterialTheme.typography.bodySmall)
                        Box {
                            OutlinedButton(onClick = { styleMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(selectedStyle, modifier = Modifier.weight(1f))
                                Text("⌄")
                            }
                            DropdownMenu(expanded = styleMenu, onDismissRequest = { styleMenu = false }) {
                                styles.forEach { style ->
                                    DropdownMenuItem(text = { Text(style) }, onClick = {
                                        selectedStyle = style; styleMenu = false
                                    })
                                }
                            }
                        }
                        Button(onClick = { improveStoryDirect() }, modifier = Modifier.fillMaxWidth(), enabled = !backendBusy) {
                            Text(if (backendBusy) "Please wait…" else "Improve with AI")
                        }
                        Text("AI rewriting runs through your configured secure backend. Review the rewritten text before using it.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("BACKEND SETTINGS", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                        OutlinedTextField(value = backendUrl, onValueChange = { backendUrl = it.trim() },
                            modifier = Modifier.fillMaxWidth(), label = { Text("HTTPS backend URL") },
                            placeholder = { Text("https://your-server.example") }, singleLine = true)
                        OutlinedTextField(value = backendToken, onValueChange = { backendToken = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("App access token") },
                            visualTransformation = PasswordVisualTransformation(), singleLine = true)
                        Text("Get these settings from the adult who manages your backend. Never enter provider API keys here.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LANGUAGE", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    Box {
                        OutlinedButton(onClick = { languageMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(selectedLanguage.label, modifier = Modifier.weight(1f)); Text("⌄")
                        }
                        DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                            (availableLanguages.ifEmpty { presetLanguages }).forEach { language ->
                                DropdownMenuItem(text = { Text(language.label) }, onClick = {
                                    selectedLanguage = language
                                    languageMenu = false
                                    lastPosition = 0
                                    engine?.let { tts ->
                                        val result = tts.setLanguage(language.locale)
                                        refreshVoices(tts, language.locale)
                                        status = if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                                            "${language.label} unavailable. Install its voice data or choose another language."
                                        else "Language changed to ${language.label}."
                                    }
                                })
                            }
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("INSTALLED VOICE", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    Box {
                        OutlinedButton(onClick = { voiceMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(selectedVoiceName, modifier = Modifier.weight(1f)); Text("⌄")
                        }
                        DropdownMenu(expanded = voiceMenu, onDismissRequest = { voiceMenu = false }) {
                            DropdownMenuItem(text = { Text("System default") }, onClick = {
                                selectedVoice = null; selectedVoiceName = "System default"; voiceMenu = false
                                status = "Using system default voice."
                            })
                            availableVoices.forEach { voice ->
                                DropdownMenuItem(text = {
                                    Column {
                                        Text(voice.name)
                                        Text("${voice.locale.displayName} · ${if (voice.isNetworkConnectionRequired) "Network required" else "May work offline"}",
                                            style = MaterialTheme.typography.labelSmall)
                                    }
                                }, onClick = {
                                    val result = engine?.setVoice(voice) ?: TextToSpeech.ERROR
                                    if (result == TextToSpeech.SUCCESS) {
                                        selectedVoice = voice
                                        selectedVoiceName = voice.name
                                        status = "Voice changed to ${voice.name}."
                                    } else status = "Could not select this voice. Try another one."
                                    voiceMenu = false
                                })
                            }
                        }
                    }
                    Text("Only voices installed and exposed by your Android Text-to-Speech engine appear here. Male/female labels are not standardized across engines.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Speaking speed", modifier = Modifier.weight(1f))
                        Text("${"%.1f".format(speed)}×", color = MaterialTheme.colorScheme.secondary)
                    }
                    Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.5f..2f)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Pitch", modifier = Modifier.weight(1f))
                        Text("${"%.1f".format(pitch)}×", color = MaterialTheme.colorScheme.secondary)
                    }
                    Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.5f..2f)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { lastPosition = 0; startSpeaking(0) }, modifier = Modifier.weight(1f), enabled = ready) { Text("▶ Speak") }
                    OutlinedButton(onClick = {
                        if (speaking && !paused) {
                            if (useClonedVoice) mediaPlayer?.pause() else engine?.stop()
                            speaking = false; paused = true
                            status = "Paused. Tap Resume to continue."
                        }
                    }, modifier = Modifier.weight(1f), enabled = speaking && !paused) { Text("Ⅱ Pause") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = {
                        if (paused) {
                            if (useClonedVoice && mediaPlayer != null) {
                                mediaPlayer?.start(); speaking = true; audioPlaying = true; paused = false
                                status = "Resumed your voice recording."
                            } else startSpeaking(lastPosition)
                        }
                    }, modifier = Modifier.weight(1f), enabled = paused) { Text("▶ Resume") }
                    OutlinedButton(onClick = {
                        engine?.stop(); mediaPlayer?.stop(); speaking = false; audioPlaying = false; paused = false; lastPosition = 0
                        status = "Playback stopped."
                    }, modifier = Modifier.weight(1f), enabled = speaking || paused) { Text("■ Stop") }
                }

                Divider()
                Text("YOUR RECORDINGS", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Upload a recorded audio file")
                }
                Text(audioName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("PERSONAL VOICE (OPTIONAL)", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                Text("Voice cloning is disabled by default. It can only be enabled by a parent/guardian or adult backend administrator after checking provider age rules, privacy terms and consent. Use only your own recording.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = voiceConsent, onCheckedChange = { voiceConsent = it })
                    Text("This recording is my own voice, and I have permission to submit it.", style = MaterialTheme.typography.bodySmall)
                }
                Button(onClick = {
                    val uri = audioUri
                    if (uri == null) { status = "Upload your own voice recording first." }
                    else if (!voiceConsent) { status = "Confirm that the recording is your own voice first." }
                    else if (backendUrl.isBlank() || backendToken.isBlank()) { status = "Enter backend settings first." }
                    else {
                        backendBusy = true
                        status = "Sending recording securely to your configured backend…"
                        scope.launch {
                            try {
                                clonedVoiceId = withContext(Dispatchers.IO) {
                                    BackendClient.cloneVoice(context, backendUrl, backendToken, uri, "My VoiceText Voice")
                                }
                                useClonedVoice = true
                                status = "Voice profile created. You can select it for speech."
                            } catch (e: Exception) {
                                status = e.message ?: "Voice setup failed."
                            } finally { backendBusy = false }
                        }
                    }
                }, modifier = Modifier.fillMaxWidth(), enabled = !backendBusy) {
                    Text(if (backendBusy) "Please wait…" else "Create my voice profile")
                }
                if (clonedVoiceId.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = useClonedVoice, onCheckedChange = { useClonedVoice = it })
                        Text("Use my voice profile for Speak")
                    }
                    OutlinedButton(onClick = {
                        if (backendUrl.isBlank() || backendToken.isBlank()) status = "Enter backend settings first."
                        else {
                            backendBusy = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { BackendClient.deleteVoice(backendUrl, backendToken, clonedVoiceId) }
                                    clonedVoiceId = ""
                                    useClonedVoice = false
                                    voiceConsent = false
                                    status = "Deletion requested. Verify deletion in the provider account too."
                                } catch (e: Exception) { status = e.message ?: "Could not delete voice profile." }
                                finally { backendBusy = false }
                            }
                        }
                    }, enabled = !backendBusy, modifier = Modifier.fillMaxWidth()) { Text("Delete voice profile") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = {
                        val uri = audioUri
                        if (uri != null) {
                            try {
                                mediaPlayer?.release()
                                mediaPlayer = MediaPlayer().apply {
                                    setDataSource(context, uri)
                                    setOnCompletionListener { audioPlaying = false }
                                    prepare()
                                    start()
                                }
                                audioPlaying = true
                                status = "Playing your uploaded recording."
                            } catch (e: Exception) {
                                status = "Could not play this audio file: ${e.localizedMessage ?: "unsupported format"}"
                            }
                        } else status = "Upload an audio recording first."
                    }, modifier = Modifier.weight(1f), enabled = audioUri != null) { Text("▶ Play recording") }
                    OutlinedButton(onClick = {
                        mediaPlayer?.pause()
                        audioPlaying = false
                        status = "Recording paused."
                    }, modifier = Modifier.weight(1f), enabled = audioPlaying) { Text("Ⅱ Pause") }
                    OutlinedButton(onClick = {
                        mediaPlayer?.stop()
                        mediaPlayer?.release()
                        mediaPlayer = null
                        audioPlaying = false
                        status = "Recording stopped."
                    }, modifier = Modifier.weight(1f), enabled = audioUri != null) { Text("■ Stop") }
                }
                Text("Uploaded recordings can be played as audio. They are not automatically converted into a voice that can read new text.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("STATUS", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                        Text(if (ready) status else "Starting Android Text-to-Speech…")
                    }
                }
                Text("VoiceText uses your device's installed Text-to-Speech voices. Language and voice availability depends on your speech engine.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
