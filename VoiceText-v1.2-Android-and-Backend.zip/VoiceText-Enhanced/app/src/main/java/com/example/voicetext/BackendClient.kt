package com.example.voicetext

import android.content.Context
import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

internal object BackendClient {
    private fun request(url: String, token: String, method: String, body: ByteArray? = null, contentType: String? = null): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20000
            readTimeout = 90000
            setRequestProperty("X-App-Token", token)
            if (contentType != null) setRequestProperty("Content-Type", contentType)
            if (body != null) doOutput = true
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = try { JSONObject(response).optString("detail", "Request failed ($code)") }
                catch (_: Exception) { "Request failed ($code)" }
                throw IllegalStateException(message)
            }
            return response
        } finally { connection.disconnect() }
    }

    fun rewrite(baseUrl: String, token: String, text: String, style: String): String {
        val json = JSONObject().put("text", text).put("style", style).toString().toByteArray(Charsets.UTF_8)
        return JSONObject(request("${baseUrl.trimEnd('/')}/api/story/rewrite", token, "POST", json, "application/json")).getString("text")
    }

    fun cloneVoice(context: Context, baseUrl: String, token: String, uri: Uri, name: String): String {
        val mime = context.contentResolver.getType(uri) ?: "audio/mpeg"
        val fileName = "voice-sample.${mime.substringAfter('/', "mp3").substringBefore(';')}"
        val boundary = "VoiceText-${UUID.randomUUID()}"
        val output = ByteArrayOutputStream()
        fun field(name: String, value: String) {
            output.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
        }
        field("voice_name", name)
        field("confirms_own_voice", "true")
        output.write("--$boundary\r\nContent-Disposition: form-data; name=\"audio\"; filename=\"$fileName\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
        context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(output) }
            ?: throw IllegalStateException("Could not read the selected recording.")
        output.write("\r\n--$boundary--\r\n".toByteArray())
        val response = JSONObject(request("${baseUrl.trimEnd('/')}/api/voice/clone", token, "POST", output.toByteArray(), "multipart/form-data; boundary=$boundary"))
        if (response.optBoolean("requires_verification", false)) {
            throw IllegalStateException("The voice provider requires extra owner verification. Ask the adult account administrator to complete it before using this profile.")
        }
        return response.getString("voice_id")
    }

    fun synthesize(baseUrl: String, token: String, voiceId: String, text: String, context: Context): File {
        val json = JSONObject().put("voice_id", voiceId).put("text", text).toString().toByteArray(Charsets.UTF_8)
        val response = JSONObject(request("${baseUrl.trimEnd('/')}/api/voice/speak", token, "POST", json, "application/json"))
        val bytes = Base64.decode(response.getString("audio_base64"), Base64.DEFAULT)
        return File.createTempFile("voicetext-", ".mp3", context.cacheDir).also { file -> file.writeBytes(bytes) }
    }

    fun deleteVoice(baseUrl: String, token: String, voiceId: String) {
        request("${baseUrl.trimEnd('/')}/api/voice/$voiceId", token, "DELETE")
    }
}
